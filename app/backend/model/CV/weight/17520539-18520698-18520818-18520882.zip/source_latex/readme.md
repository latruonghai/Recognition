# Các ảnh trong pdf

Đường dẫn:
[Link ảnh](https://drive.google.com/drive/folders/17JpJip5znLkAjuAXPzWIBt8UuSTwvnB-?usp=sharing)
